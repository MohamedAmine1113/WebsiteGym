<?php

/**
 * templates loader view
 */
if (!defined('ABSPATH')) exit; // Exit if accessed directly
?>
<div class="elementor-loader-wrapper">
	<div class="elementor-loader">
		<div class="elementor-loader-box"></div>
		<div class="elementor-loader-box"></div>
		<div class="elementor-loader-box"></div>
		<div class="elementor-loader-box"></div>
	</div>
	<div class="elementor-loading-title">Loading</div>
</div>